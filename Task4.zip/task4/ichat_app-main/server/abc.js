// first open terminal and type - 'cd nodeServer'
//then - 'npm init -y'
//then - 'npm i socket.io'

// & in terminal 'nodemon index.js'